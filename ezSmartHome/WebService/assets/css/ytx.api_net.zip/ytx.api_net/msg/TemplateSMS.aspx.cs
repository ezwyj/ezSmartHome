﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;

namespace demo.msg
{
    public partial class TemplateSMS : System.Web.UI.Page
    {
        //云通信平台创建的 应用 AppID
        public static string appID = "cbc6ceb21fd34664b6e452ca2aa40b3f";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            //0、电话号码 验证码 验证
            //1、构建访问参数
             string jsonData = getJsonData("接收号码", "平台应用id","短信模板id","验证码字符串","有效时长（分钟）");
            //事例
             jsonData= "{\"action\":\"templateSms\",\"mobile\":\"" + this.tb_number.Text.Trim() +"\",\"appid\":\"" + appID +"\",\"templateId\":\"1\",\"datas\":[\""+this.code.Text.Trim()+"\",\""+this.expdate.Text.Trim()+"\"]}";
    
            //2、云通信平台接口请求URL
             string url = "/sms/TemplateSMS.wx";//默认值 /sms/TemplateSMS.wx
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        //构建访问短信接口的参数json字符串
        private string getJsonData(string telNum, string appID,string templateId,string code,string expdate)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("{");
            builder.Append("\"action\":\"templateSms\"");//必选参数，默认值 templateSms
            builder.Append(",\"mobile\":\"").Append(telNum).Append("\"");
            builder.Append(",\"appId\":\"").Append(appID).Append("\"");
            builder.Append(",\"templateId\":\"").Append(templateId).Append("\"");
            builder.Append(",\"datas\":[");
            builder.Append("\"" + code + "\"");
            builder.Append(",\"" + expdate + "\"");
            builder.Append("]");
            builder.Append("}");
            return builder.ToString();
        }




    }
}
