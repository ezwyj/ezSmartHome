﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Collections.Generic;

namespace demo.traffic
{

    public class Parms
    {

        private Parms(){}
        static Parms()
        {
            Instance = new Parms();
            dicProvinceCode.Add("全国", "QG");
            dicProvinceCode.Add("安徽", "AH");
            dicProvinceCode.Add("北京", "BJ");
            dicProvinceCode.Add("重庆", "CQ");
            dicProvinceCode.Add("福建", "FJ");
            dicProvinceCode.Add("广东", "GD");
            dicProvinceCode.Add("甘肃", "GS");
            dicProvinceCode.Add("广西", "GX");
            dicProvinceCode.Add("贵州", "GZ");
            dicProvinceCode.Add("湖北", "HE");
            dicProvinceCode.Add("河北", "HJ");
            dicProvinceCode.Add("黑龙", "HL");
            dicProvinceCode.Add("湖南", "HX");
            dicProvinceCode.Add("海南", "HQ");
            dicProvinceCode.Add("河南", "HY");
            dicProvinceCode.Add("吉林", "JL");
            dicProvinceCode.Add("江苏", "JS");
            dicProvinceCode.Add("江西", "JX");
            dicProvinceCode.Add("辽宁", "LN");
            dicProvinceCode.Add("内蒙", "NM");
            dicProvinceCode.Add("宁夏", "NX");
            dicProvinceCode.Add("青海", "QH");
            dicProvinceCode.Add("四川", "SC");
            dicProvinceCode.Add("山东", "SD");
            dicProvinceCode.Add("上海", "SH");
            dicProvinceCode.Add("山西", "SJ");
            dicProvinceCode.Add("陕西", "SS");
            dicProvinceCode.Add("天津", "TJ");
            dicProvinceCode.Add("西藏", "XZ");
            dicProvinceCode.Add("新疆", "XJ");
            dicProvinceCode.Add("云南", "YN");
            dicProvinceCode.Add("浙江", "ZJ"); 
        }

        /// <summary>
        /// 省份对应代码字典
        /// </summary>
        public static Dictionary<string, string> dicProvinceCode = new Dictionary<string, string>();
        public static Parms Instance
        {
            private set;
            get;
        }
        //云通信平台的  ACCOUNT SID
        public string accountSID = "89bf148d5b734684556a34cf19e53dce";
        //云通信平台的  AUTH TOKEN
        public string authToken = "892eb89d034355bdb08cbe0d4793e613";

    }

    public partial class TrafficV201612 : System.Web.UI.Page
    {
        //云通信平台创建的 应用 AppID
        public string appID = "55c3d7ccd9b14debb0d8b0f5460d92d7";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //0、手机号码及其他参数有效性验证
            //1、得到手机号码所属运营商及归属地
            //2、构造流量代码。此代码通常情况下可以由下面的规则生成.特殊情况根据我方给出的代码为准。
                //第1位表示号码所属运营商[1移动 2电信 3联通] 
                //第2-3位表示充值通道[全国口或者省口],全国口[QG],省口用手机归属地字母代替.具体见Parms.dicProvinceCode
                //第4-9位共6位表示充值流量包大小，不够6位左补0
                //第10位表示流量的属性[1标准包 2红包 3快餐 4转增]
                //第11位表示流量支持的漫游情况 0全国漫游 1省内漫游
                //eg: 1BJ00001020 表示移动北京省网10M红包支持全国漫游 2QG00001011 表示电信全网10M标准包支持省内漫游
            //3、构建访问参数
            //4、发送请求，处理提交结果
            string accountsid = this.txt_accountsid.Text.Trim();
            string authtoken = this.txt_authtoken.Text.Trim();
            string appidextend = this.txt_appid.Text.Trim();
            if (string.IsNullOrEmpty(accountsid) || string.IsNullOrEmpty(authtoken) || string.IsNullOrEmpty(appidextend))
            {
                string jsonData = "{\"action\":\"flowOrder\",\"phone\":\"" + this.teleNum.Text.Trim() + "\",\"flowCode\":\"" + this.flowcode.Text.Trim() + "\",\"appid\":\"" + appID + "\",\"customParm\":\"1\"}";
                //2、云通信平台接口请求URL
                string url = "/traffic/Traffic.wx";
                //3、发送http请求，接收返回错误消息
                //this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
                this.Label1.Text = demo.CommenHelper.SendRequest(demo.traffic.Parms.Instance.accountSID, demo.traffic.Parms.Instance.authToken, url, jsonData);

            }
            else {
                string jsonData = "{\"action\":\"flowOrder\",\"phone\":\"" + this.teleNum.Text.Trim() + "\",\"flowCode\":\"" + this.flowcode.Text.Trim() + "\",\"appid\":\"" + appidextend + "\",\"effectStartTime\":\"1\",\"effectTime\":\"1\",\"customParm\":\"1\"}";
                //2、云通信平台接口请求URL
                string url = "/traffic/Traffic.wx";
                //3、发送http请求，接收返回错误消息
                this.Label1.Text = demo.CommenHelper.SendRequest(accountsid, authtoken, url, jsonData);
            }
        }

        protected static DataSet GetDataSetByXml(string xmlData)
        {
           try
           {
               DataSet ds = new DataSet(); 

               using (StringReader xmlSR = new StringReader(xmlData))
               { 

                   ds.ReadXml(xmlSR, XmlReadMode.InferTypedSchema); //忽视任何内联架构，从数据推断出强类型架构并加载数据
                   if (ds.Tables.Count > 0)
                   {
                       return ds;
                   }
               }
               return null;
           }
           catch (Exception)
           {
               return null;
           }
        } 

        private string CheckRBIndex(RadioButton[] radiobutton)
        {
            int index = 0;
                for( int i=0;i<3;i++)
                {
                   if(radiobutton[i].Checked == true)
                  {
                      index = i;
                   }
                }
                return (index + 1).ToString();
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            //0、电话号码及其他参数有效性验证
            //1、构建访问参数
            string accountsid = this.txt_accountsid.Text.Trim();
            string authtoken = this.txt_authtoken.Text.Trim();
            string appidextend = this.txt_appid.Text.Trim();
            if (string.IsNullOrEmpty(accountsid) || string.IsNullOrEmpty(authtoken) || string.IsNullOrEmpty(appidextend))
            {
                string jsonData = "{\"action\":\"getTrafficResult\",\"requestId\":\"" + this.txtrequestid.Text.Trim() + "\",\"appid\":\"" + appID + "\"}";
                //2、云通信平台接口请求URL
                string url = "/traffic/Traffic.wx";
                //3、发送http请求，接收返回错误消息
                this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
            }
            else
            {
                string jsonData = "{\"action\":\"getTrafficResult\",\"requestId\":\"" + this.txtrequestid.Text.Trim() + "\",\"appid\":\"" + appidextend + "\"}";
                //2、云通信平台接口请求URL
                string url = "/traffic/Traffic.wx";
                //3、发送http请求，接收返回错误消息
                this.Label1.Text = demo.CommenHelper.SendRequest(accountsid, authtoken, url, jsonData);
            }
        }
    }
}
