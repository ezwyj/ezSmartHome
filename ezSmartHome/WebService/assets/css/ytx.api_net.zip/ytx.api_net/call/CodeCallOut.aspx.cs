﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Net;
using System.IO;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace demo.call
{
    public partial class CodeCallOut : System.Web.UI.Page
    {
        //云通信平台创建的 应用 AppID
        public string appID = "1546fe33e2ff43dd885658c078ce5ce1";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //0、电话号码 验证码 验证
            //1、构建访问参数
            string jsonData = "{\"action\":\"callOutCode\",\"dst\":\"" + this.dst.Text.Trim() + "\",\"appid\":\""+appID+"\",\"code\":\""+this.code.Text.Trim()+"\"}";
            //2、云通信平台接口请求URL
            string url ="/call/CodeCallOut.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

      
    }
}
