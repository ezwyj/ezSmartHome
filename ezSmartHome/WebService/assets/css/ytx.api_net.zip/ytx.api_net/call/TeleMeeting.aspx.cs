﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace demo
{
    public partial class TeleMeeting : System.Web.UI.Page
    {
        //云通信平台创建的 应用 AppID
        public string appID = "55c3d7ccd9b14debb0d8b0f5460d92d7";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            //发起开会
            string jsonData = "{\"action\":\"createMeeting\",\"appid\":\"" + appID + "\",\"meetingname\":\"" + mename.Text + "\",\"creator\":\"" + creator.Text + "\",\"parties\":\"" + info.Text + "\",\"bookmeeting\":\"" + ifbook.Text + "\",\"confid\":\"" + meid.Text + "\",\"booktime\":\"" + booktime.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            //邀请开会
            string jsonData = "{\"action\":\"inviteJoinMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + yqmeid.Text + "\",\"parties\":\"" + yqinfo.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            //终止开会
            string jsonData = "{\"action\":\"destroyMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + jsmeid.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);

        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            //查询会议
            string jsonData = "{\"action\":\"queryMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + cxmeid.Text + "\",\"meetingcount\":\"" + meetingcount.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/MeetingQuery.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            //静音
            string jsonData = "{\"action\":\"muteMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + jymeid.Text + "\",\"parties\":\"" + jyphone.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            //取消静音
            string jsonData = "{\"action\":\"unmuteMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + qxmeid.Text + "\",\"parties\":\"" + qxphone.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            //挂断
            string jsonData = "{\"action\":\"hangupMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + gdmeid.Text + "\",\"phone\":\"" + gdphone.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            //状态
            string jsonData = "{\"action\":\"meetingState\",\"appid\":\"" + appID + "\",\"confid\":\"" + ztmeid.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            //回锁
            string jsonData = "{\"action\":\"lockMeeting\",\"appid\":\"" + appID + "\",\"confid\":\"" + hsmeid.Text + "\",\"lackstate\":\"" + lockstate.Text + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/TeleMeeting.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }

    }
}
