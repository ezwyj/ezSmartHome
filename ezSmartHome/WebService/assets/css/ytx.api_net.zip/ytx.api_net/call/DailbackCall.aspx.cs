﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace demo
{
    public partial class DailbackCall : System.Web.UI.Page
    {
        //云通信平台创建的 应用 AppID
        public string appID = "e196738455314695bd6960a13a205d72";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //0、电话号码及其他参数有效性验证
            //1、构建访问参数
            string jsonData = "{\"action\":\"callDailBack\",\"src\":\"" + this.src.Text.Trim() + "\",\"dst\":\"" + this.dst.Text.Trim() + "\",\"appid\":\"" + appID + "\",\"credit\":\"" + this.credit.Text.Trim() + "\"}";
            //2、云通信平台接口请求URL
            string url = "/call/DailbackCall.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }
    }
}
