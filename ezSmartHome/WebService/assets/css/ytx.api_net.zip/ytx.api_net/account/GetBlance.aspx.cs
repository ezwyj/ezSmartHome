﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace demo.account
{
    public partial class GetBlance : System.Web.UI.Page
    {
        public string appID = "55c3d7ccd9b14debb0d8b0f5460d92d7";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //发起开会
            string jsonData = "{\"action\":\"queryBlance\",\"appid\":\""+appID+"\"}";
            //2、云通信平台接口请求URL
            string url = "/account/getBlance.wx";
            //3、发送http请求，接收返回错误消息
            this.Label1.Text = demo.CommenHelper.SendRequest(url, jsonData);
        }
    }
}
